﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;
using TaskManagement.Models;
using TaskManagementContext;
using TaskManagementService;
using TaskManagementWebApp.Models;

namespace TaskManagement.Controllers
{
    public class TaskController : Controller
    {
        private readonly ILogger<TaskController> logger;

        private readonly ITaskService taskService;

        /// <summary>
        /// Contructor to inject dependencies
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="taskService"></param>
        public TaskController(ILogger<TaskController> logger, ITaskService taskService)
        {
            this.logger = logger;
            this.taskService = taskService;
        }

        /// <summary>
        /// Method to render task list page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var taskList = await this.taskService.GetAllAsync();
            List<TaskViewModel> tasksList = new List<TaskViewModel>();
            taskList.ToList().ForEach(item =>
            {
                tasksList.Add(new TaskViewModel
                {
                    Id = item.Id,
                    Name = item.Name,
                    Description = item.Description,
                    Status = item.Status,
                });
            });

            return View(tasksList);
        }

        /// <summary>
        /// Method to render task create page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var taskDetail = new TaskViewModel();
            taskDetail.TaskStatus = new SelectList(GetStatusData(), "Id", "Name");
            return View(taskDetail);
        }

        /// <summary>
        /// Method to save new task
        /// </summary>
        /// <param name="taskViewModel">Task View Model</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Create(TaskViewModel taskViewModel)
        {
            if(!ModelState.IsValid)
            {
                var task = new TaskViewModel();
                task.TaskStatus = new SelectList(GetStatusData(), "Id", "Name");
                return View(task);
            }

            TaskDetail taskDetail = new TaskDetail
            {
                Id = taskViewModel.Id,
                Name = taskViewModel.Name,
                Description = taskViewModel.Description,
                Status = taskViewModel.Status,
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            };

            await this.taskService.AddAsync(taskDetail);
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Method to render task update page
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Update(int taskId)
        {
            var task = await this.taskService.GetByIdAsync(taskId);
            var taskDetail = new TaskViewModel
            {
                Id = task.Id,
                Name = task.Name,
                Description = task.Description,
                Status = task.Status
            };

            ViewBag.Taskstatus = taskDetail.Status;
            taskDetail.TaskStatus = new SelectList(GetStatusData(), "Id", "Name");
            return View(taskDetail);
        }

        /// <summary>
        /// Method to save updated task detail
        /// </summary>
        /// <param name="taskDetail"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Update(TaskViewModel taskViewModel)
        {
            if (!ModelState.IsValid)
            {
                //var task = new TaskViewModel();
                //task.TaskStatus = new SelectList(GetStatusData(), "Id", "Name");
                return View(taskViewModel);
            }

            TaskDetail taskDetail = new TaskDetail
            {
                Id = taskViewModel.Id,
                Name = taskViewModel.Name,
                Description = taskViewModel.Description,
                Status = taskViewModel.Status,
                UpdatedDate = DateTime.UtcNow
            };

            await this.taskService.UpdateAsync(taskDetail);
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Method to delete task
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Delete(int taskId)
        {
            await this.taskService.DeleteAsync(taskId);
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Method to generate Task Status Dropdown data
        /// </summary>
        /// <returns></returns>
        private List<TaskStatusViewModel> GetStatusData()
        {
            return new List<TaskStatusViewModel>
            {
                new TaskStatusViewModel
                {
                    Id = 1,
                    Name = "Pending"
                },
                new TaskStatusViewModel
                {
                    Id = 2,
                    Name = "Submitted"
                },
                new TaskStatusViewModel
                {
                    Id = 3,
                    Name = "New"
                }
            };
        }
    }
}