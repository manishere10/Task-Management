﻿namespace TaskManagement.Models
{
    public class IndexViewModel
    {
        public IList<TaskViewModel> TaskLists { get; set; }
    }
}
