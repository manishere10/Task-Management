using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using TaskManagementWebApp.Models;

namespace TaskManagement.Models
{
    public class TaskViewModel
    {
        /// <summary>
        /// gets or sets id of the task
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets Name of the task
        /// </summary>
        [Required(ErrorMessage = "The Name field is required.")]
        public string Name { get; set; }

        /// <summary>
        /// gets or sets Decsription of the task
        /// </summary>
        [Required(ErrorMessage = "The Name field is required.")]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets status of the task
        /// </summary>
        [Required(ErrorMessage = "The Name field is required.")]
        public int Status { get; set; }

        /// <summary>
        /// Holds Task Status dropdown data
        /// </summary>
        public SelectList TaskStatus { get; set; }
    }
}