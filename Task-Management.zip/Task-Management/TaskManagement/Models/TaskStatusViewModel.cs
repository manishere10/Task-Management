﻿namespace TaskManagementWebApp.Models
{
    public class TaskStatusViewModel
    {
        /// <summary>
        /// Holds Status Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Holds status Name
        /// </summary>
        public string Name { get; set; }
    }
}
