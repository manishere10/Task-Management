﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace TaskManagementContext
{
    public class TaskRepository : ITaskRepository
    {
        /// <summary>
        /// Property to hold configuration detail
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// Constructor to inject requird dependencies
        /// </summary>
        /// <param name="configuration">Configuration Object</param>
        public TaskRepository(IConfiguration configuration) 
        {
            this.configuration= configuration;
        }

        /// <summary>
        /// Establishes DB Connection
        /// </summary>
        public IDbConnection dbConnection => new SqlConnection(this.configuration.GetConnectionString("TaskDb"));

        /// <summary>
        /// Method to add new task
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        public async Task<int> AddAsync(TaskDetail task)
        {
            using (var connection = this.dbConnection)
            {
                connection.Open();
                return await connection.ExecuteAsync("INSERT INTO TaskDetail (Name, Description, Status, Active, CreatedDate, UpdatedDate) VALUES (@Name, @Description, @Status, 1, @CreatedDate, @UpdatedDate)", task);
            }
        }

        /// <summary>
        /// Method to delete a task by task id
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public async Task<int> DeleteAsync(int taskId)
        {
            using (var connection = this.dbConnection)
            {
                connection.Open();
                return await connection.ExecuteAsync("Update TaskDetail Set Active = 0 WHERE Id = @Id", new { Id = taskId });
            }
        }

        /// <summary>
        /// Method to fetch all tasks
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<TaskDetail>> GetAllAsync()
        {
            using (var connection = this.dbConnection)
            {
                connection.Open();
                return await connection.QueryAsync<TaskDetail>("SELECT * FROM TaskDetail WHERE Active = 1");
            }
        }

        /// <summary>
        /// Method to fetch task by task id
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public async Task<TaskDetail> GetByIdAsync(int taskId)
        {
            using (var connection = this.dbConnection)
            {
                connection.Open();
                return await connection.QueryFirstOrDefaultAsync<TaskDetail>("SELECT * FROM TaskDetail WHERE Id = @Id", new { Id = taskId });
            }
        }

        /// <summary>
        /// Method to update TaskDetail details
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        public async Task<int> UpdateAsync(TaskDetail task)
        {
            using (var connection = this.dbConnection)
            {
                connection.Open();
                return await connection.ExecuteAsync("UPDATE TaskDetail SET Name = @Name, Description = @Description, Status = @Status, UpdatedDate = @UpdatedDate WHERE Id = @Id", task);
            }
        }
    }
}
