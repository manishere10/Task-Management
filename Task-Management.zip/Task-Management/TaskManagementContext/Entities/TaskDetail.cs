﻿namespace TaskManagementContext
{
    public class TaskDetail
    {
        /// <summary>
        /// gets or sets id of the task
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets Name of the task
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// gets or sets Decsription of the task
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets status of the task
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// gets or sets the created date of the task
        /// </summary>
        public DateTime CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets the updated date of the task
        /// </summary>
        public DateTime UpdatedDate { get; set; }
    }
}
