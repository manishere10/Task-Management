﻿using TaskManagementContext;

namespace TaskManagementService
{
    public interface ITaskService
    {
        /// <summary>
        /// Method to fetch all tasks
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<TaskDetail>> GetAllAsync();

        /// <summary>
        /// Method to fetch a task by Id
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        Task<TaskDetail> GetByIdAsync(int taskId);

        /// <summary>
        /// Method to add a task
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        Task<int> AddAsync(TaskDetail task);

        /// <summary>
        /// Method to update a task
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        Task<int> UpdateAsync(TaskDetail task);

        /// <summary>
        /// Method to delete a task
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        Task<int> DeleteAsync(int taskId);
    }
}
