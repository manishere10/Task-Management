﻿using TaskManagementContext;

namespace TaskManagementService
{
    public class TaskService : ITaskService
    {
        public ITaskRepository taskRepository { get; }

        public TaskService(ITaskRepository taskRepository) 
        {
            this.taskRepository = taskRepository;
        }

        /// <summary>
        /// Method to add new task
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        public async Task<int> AddAsync(TaskDetail task)
        {
            return await this.taskRepository.AddAsync(task);
        }

        /// <summary>
        /// Method to delete a task by task id
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public async Task<int> DeleteAsync(int taskId)
        {
            return await this.taskRepository.DeleteAsync(taskId);
        }

        /// <summary>
        /// Method to fetch all tasks
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<TaskDetail>> GetAllAsync()
        {
            return await this.taskRepository.GetAllAsync();
        }

        /// <summary>
        /// Method to fetch task by task id
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public async Task<TaskDetail> GetByIdAsync(int taskId)
        {
            return await this.taskRepository.GetByIdAsync(taskId);
        }

        /// <summary>
        /// Method to update TaskDetail details
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        public async Task<int> UpdateAsync(TaskDetail task)
        {
            return await this.taskRepository.UpdateAsync(task);
        }
    }
}
